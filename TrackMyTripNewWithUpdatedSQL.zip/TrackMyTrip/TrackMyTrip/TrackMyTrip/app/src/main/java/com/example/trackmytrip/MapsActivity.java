package com.example.trackmytrip;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.SphericalUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import static java.lang.Double.doubleToLongBits;
import static java.lang.Double.parseDouble;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback,
        GoogleApiClient.OnConnectionFailedListener {
    FusedLocationProviderClient client;
    private Context mContext;
    private EditText searchPlaceEt;
    private Button saveLocationBtn;
    private GoogleMap mMap;
    private GoogleApiClient mGoogleApiClient;
    MyDataBaseHelper myDB;
    ArrayList<Integer> id;
    ArrayList<Integer> interval;
    ArrayList<String> tripname,tripdate;
    ArrayList<String> actualTripName,getActualTripDate;
    ArrayList<Double> latitude,longitude;
    ArrayList<Integer> frequency;
    ArrayList<Integer> dummyfrequency;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        //Initialize fused Location
        client = LocationServices.getFusedLocationProviderClient(this);

        //get data from database

        myDB = new MyDataBaseHelper(MapsActivity.this);
        id=new ArrayList<Integer>();
        interval=new ArrayList<Integer>();
        tripname = new ArrayList<>();
        tripdate = new ArrayList<>();
        latitude=new ArrayList<>();
        longitude=new ArrayList<>();

        frequency = new ArrayList<>();
        dummyfrequency = new ArrayList<>();

        actualTripName=new ArrayList<>();
        getActualTripDate=new ArrayList<>();
        //sync of the database to the respective arraylist
        displayData();

        //positionOfTrip = Integer.valueOf(string);
        //checking for trips context

        mContext = MapsActivity.this;

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                //Location Permission already granted


                if (mMap != null)
                    mMap.setMyLocationEnabled(true);
            } else {
                //Request Location Permission
                ///checkLocationPermission();
            }
        }
    }

    private void displayData() {
        Cursor cursor = myDB.readAllData();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No Data", Toast.LENGTH_LONG).show();
        } else {
            while (cursor.moveToNext()) {
                id.add(cursor.getInt(0));
                tripdate.add(cursor.getString(1));
                tripname.add(cursor.getString(2));
                interval.add(cursor.getInt(3));
                latitude.add(cursor.getDouble(4));
                longitude.add(cursor.getDouble(5));
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onMapReady(GoogleMap googleMap) {
        //get the list of loactions
        ArrayList uniqueList = (ArrayList) id.stream().distinct().collect(Collectors.toList());
        System.out.println(uniqueList);
        double getLatitude, getLongitude;
        ArrayList<LatLng> latsAndLong = new ArrayList<>();
        double dist=0;

        Intent intent = getIntent();
        int string = intent.getIntExtra("positionOfTrip", 0);
        //getting the unique position/id
        int position= (int) uniqueList.get(string);

        int occurences=0;

        for (int i=0;i<=uniqueList.size()-1;i++) {
            occurences = Collections.frequency(id, uniqueList.get(i));
            frequency.add(occurences);
        }
        System.out.println(frequency);
        int j=0;
        for (int i=0;i<=frequency.size()-1;i++)
        {

            j=j+frequency.get(i);
            dummyfrequency.add(j);

        }
        System.out.println(dummyfrequency);
        //inserting the unique names and dates

        for (int i=0;i<=dummyfrequency.size()-1;i++) {
            actualTripName.add(tripname.get(dummyfrequency.get(i)-1));
            getActualTripDate.add(tripdate.get(dummyfrequency.get(i)-1));
        }
        System.out.println(actualTripName);
        System.out.println(getActualTripDate);

        //checking the position received
        //Toast.makeText(getApplicationContext(), "The Received Position is : " + string, Toast.LENGTH_LONG).show();


        //System.out.println(latitude.size());
        //System.out.println(longitude.size());

        mMap = googleMap;

        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        for (int i = 0; i < latitude.size(); i++) {

            getLatitude = latitude.get(i);
            getLongitude = longitude.get(i);

            LatLng latLng = new LatLng(getLatitude, getLongitude);
            //System.out.println(latLng.latitude);
            //System.out.println(latLng.longitude);
            latsAndLong.add(latLng);
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latsAndLong.get(0), 19));
            mMap.animateCamera(CameraUpdateFactory.zoomTo(10));
            mMap.setBuildingsEnabled(true);
        }


        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latsAndLong.get(0), 18));
        MarkerOptions optionsfirst = new MarkerOptions().position(latsAndLong.get(0)).title("This is first location");
        mMap.addMarker(optionsfirst);
        MarkerOptions optionslast = new MarkerOptions().position(latsAndLong.get(latsAndLong.size() - 1)).title("This is last location");
        mMap.addMarker(optionslast);


        for (int k = 0; k < latsAndLong.size() - 1; k++) {
            PolylineOptions line = new PolylineOptions().add((latsAndLong.get(k)), latsAndLong.get(k + 1)).width(10).color(Color.RED);
            mMap.addPolyline(line);
        }
        for (int k = 0; k < latsAndLong.size() - 1; k++) {
        dist = dist+SphericalUtil.computeDistanceBetween(latsAndLong.get(k), latsAndLong.get(k+1));
        System.out.println(dist);
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }


}
