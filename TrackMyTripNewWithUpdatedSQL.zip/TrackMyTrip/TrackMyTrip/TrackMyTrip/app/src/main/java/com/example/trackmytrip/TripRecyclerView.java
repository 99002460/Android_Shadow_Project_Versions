package com.example.trackmytrip;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Collectors;

public class TripRecyclerView extends AppCompatActivity {
    RecyclerView recyclerView;
    MyDataBaseHelper myDB;
    ArrayList<Integer> id;
    ArrayList<Integer> interval;
    ArrayList<String> tripname,tripdate;
    ArrayList<String> actualTripName,getActualTripDate;
    ArrayList<Double> latitude,longitude;
    ArrayList<Integer> frequency;
    ArrayList<Integer> dummyfrequency;
    CustomAdapter customAdapter;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_recycler_view);
        recyclerView=findViewById(R.id.tripsView);
        Intent intent=getIntent();

        myDB = new MyDataBaseHelper(TripRecyclerView.this);
        id=new ArrayList<Integer>();
        interval=new ArrayList<Integer>();
        tripname = new ArrayList<>();
        tripdate = new ArrayList<>();
        latitude=new ArrayList<>();
        longitude=new ArrayList<>();

        frequency = new ArrayList<>();
        dummyfrequency = new ArrayList<>();

        actualTripName=new ArrayList<>();
        getActualTripDate=new ArrayList<>();

        displayData();
        int occurences=0;

        ArrayList uniqueList = (ArrayList) id.stream().distinct().collect(Collectors.toList());
        System.out.println(uniqueList);
        for (int i=0;i<=uniqueList.size()-1;i++) {
            occurences = Collections.frequency(id, uniqueList.get(i));
            frequency.add(occurences);
        }
        System.out.println(frequency);
        int j=0;
        for (int i=0;i<=frequency.size()-1;i++)
        {

            j=j+frequency.get(i);
            dummyfrequency.add(j);

        }
        System.out.println(dummyfrequency);
        //inserting the unique names and dates

        for (int i=0;i<=dummyfrequency.size()-1;i++) {
            actualTripName.add(tripname.get(dummyfrequency.get(i)-1));
            getActualTripDate.add(tripdate.get(dummyfrequency.get(i)-1));
        }
        System.out.println(actualTripName);
        System.out.println(getActualTripDate);

        customAdapter = new CustomAdapter(TripRecyclerView.this,actualTripName,getActualTripDate,new ClickListerner(){
            @Override public void onPositionClicked(int position) {
                // callback performed on click

                Intent intent = new Intent(TripRecyclerView.this,MapsActivity.class);
                intent.putExtra("positionOfTrip", position);
                startActivity(intent);

            }
        });
        recyclerView.setAdapter(customAdapter);

        recyclerView.setLayoutManager(new LinearLayoutManager(TripRecyclerView.this));
    }
    void displayData(){
        Cursor cursor = myDB.readAllData();
        if (cursor.getCount()==0)
        {
            Toast.makeText(this,"No Data",Toast.LENGTH_LONG).show();
        }
        else
        {
            while (cursor.moveToNext()){
//                tripdate.add(cursor.getString(0));
//                tripname.add(cursor.getString(1));
//
//                tripdetails.add(cursor.getString(2));
                id.add(cursor.getInt(0));
                tripdate.add(cursor.getString(1));
                tripname.add(cursor.getString(2));
                interval.add(cursor.getInt(3));
                latitude.add(cursor.getDouble(4));
                longitude.add(cursor.getDouble(5));
            }
        }
    }


}