package com.example.trackmytrip;

import android.view.View;

public interface MyViewHolder {
    // onClick Listener for view
    void onClick(View v);
}
