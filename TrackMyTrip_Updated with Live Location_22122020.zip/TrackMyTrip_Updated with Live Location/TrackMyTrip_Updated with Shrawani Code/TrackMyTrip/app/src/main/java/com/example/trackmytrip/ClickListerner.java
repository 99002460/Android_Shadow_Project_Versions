package com.example.trackmytrip;

public interface ClickListerner {
    void onPositionClicked(int position);

    void onDeleteClick(int position);
}
