package com.example.triptrack;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.AdapterView;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Settings extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    String[] timer={"10 seconds","30 seconds","1 minutes","5 minutes"};
    Button submit;
    EditText tripName;
    String trip,timerposition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        Intent intent = getIntent();


        submit = (Button) findViewById(R.id.button);
        tripName =(EditText) findViewById(R.id.tripName);



        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                trip= tripName.getText().toString();
                Intent in = new Intent(Settings.this, MainActivity.class);
                Bundle data1=new Bundle();
                data1.putString("tripname",trip);
                data1.putString("timerposition",timerposition);
                in.putExtras(data1);
                Toast.makeText(getApplicationContext(),"Trip Started!",Toast.LENGTH_LONG).show();
                startActivity(in);
            }
        });



                //Getting the instance of Spinner and applying OnItemSelectedListener on it
        Spinner spin = (Spinner) findViewById(R.id.spinner);
        spin.setOnItemSelectedListener(this);

//Creating the ArrayAdapter instance having the bank name list
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_item,timer);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//Setting the ArrayAdapter data on the Spinner
        spin.setAdapter(aa);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
        Toast.makeText(getApplicationContext(), timer[position], Toast.LENGTH_LONG).show();
        timerposition=timer[position];
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}